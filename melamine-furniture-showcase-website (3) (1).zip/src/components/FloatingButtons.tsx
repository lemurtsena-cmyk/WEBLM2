import { useState } from 'react';
import { MapPin, Settings } from 'lucide-react';

const WHATSAPP_URL = `https://wa.me/261340000000?text=Bonjour%20Lemur%20Tsena%2C%20je%20souhaite%20un%20devis%20pour%20un%20meuble.`;
const MAPS_URL = 'https://maps.app.goo.gl/QE2fLJJs491LqYW17';

interface FloatingButtonsProps {
  onAdminClick: () => void;
}

export default function FloatingButtons({ onAdminClick }: FloatingButtonsProps) {
  const [showTooltip, setShowTooltip] = useState<string | null>(null);

  return (
    <div className="fixed bottom-6 right-6 z-40 flex flex-col gap-3 items-end">

      {/* Admin Button */}
      <div className="relative">
        {showTooltip === 'admin' && (
          <div className="absolute right-14 top-1/2 -translate-y-1/2 bg-gray-800 text-white text-xs px-3 py-1.5 rounded-lg whitespace-nowrap shadow-lg">
            Panneau Admin
          </div>
        )}
        <button
          onClick={onAdminClick}
          onMouseEnter={() => setShowTooltip('admin')}
          onMouseLeave={() => setShowTooltip(null)}
          className="w-12 h-12 bg-primary text-white rounded-full shadow-lg shadow-primary/40 flex items-center justify-center hover:bg-primary-light transition-all duration-300 hover:scale-110"
          aria-label="Administration"
        >
          <Settings size={20} />
        </button>
      </div>

      {/* Google Maps Button */}
      <div className="relative">
        {showTooltip === 'maps' && (
          <div className="absolute right-14 top-1/2 -translate-y-1/2 bg-gray-800 text-white text-xs px-3 py-1.5 rounded-lg whitespace-nowrap shadow-lg">
            Nous trouver
          </div>
        )}
        <a
          href={MAPS_URL}
          target="_blank"
          rel="noopener noreferrer"
          onMouseEnter={() => setShowTooltip('maps')}
          onMouseLeave={() => setShowTooltip(null)}
          className="w-12 h-12 bg-red-500 text-white rounded-full shadow-lg shadow-red-500/40 flex items-center justify-center hover:bg-red-600 transition-all duration-300 hover:scale-110"
          aria-label="Google Maps"
        >
          <MapPin size={22} />
        </a>
      </div>

      {/* WhatsApp Button (bigger, primary CTA) */}
      <div className="relative">
        {showTooltip === 'whatsapp' && (
          <div className="absolute right-16 top-1/2 -translate-y-1/2 bg-gray-800 text-white text-xs px-3 py-1.5 rounded-lg whitespace-nowrap shadow-lg">
            Demander un devis
          </div>
        )}
        <a
          href={WHATSAPP_URL}
          target="_blank"
          rel="noopener noreferrer"
          onMouseEnter={() => setShowTooltip('whatsapp')}
          onMouseLeave={() => setShowTooltip(null)}
          className="w-14 h-14 bg-green-500 text-white rounded-full shadow-xl shadow-green-500/50 flex items-center justify-center hover:bg-green-600 transition-all duration-300 hover:scale-110 relative"
          aria-label="WhatsApp"
        >
          {/* Ping animation */}
          <span className="absolute inset-0 rounded-full bg-green-400 animate-ping opacity-30" />
          <svg viewBox="0 0 24 24" width="26" height="26" fill="currentColor" className="relative z-10">
            <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
          </svg>
        </a>
      </div>
    </div>
  );
}
